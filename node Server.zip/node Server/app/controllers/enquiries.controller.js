const db = require("../models");
const emailConfig = require("../config/email.config.js");
const Enquiries = db.enquiries;    
// Create and Save a new Tutorial
//Mail Sent functionality
var nodemailer = require('nodemailer');
const hbs=require('nodemailer-express-handlebars');

exports.create = (req, res) => {
  // Validate request
  if (!req.body.customerName) {
    res.status(400).send({ message: " Content can not be empty!",ress:req });
    return;
  }
  // Create a Tutorial
  const enquiry = new Enquiries({
    customerName:req.body.customerName,
    toEmail:req.body.toEmail,
    subject:req.body.subject,
    content:req.body.content,
    contactNumber:req.body.contactNumber,
    
  });

 
  //Email Functionality Strts

  var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: emailConfig.senderEmailID,
      pass: emailConfig.senderEmailPassword
    }
  });
// point to the template folder
 const handlebarOptions = {
   viewEngine:{
     
       defaultLayout: false
   },
   
   viewPath: './emailTemplates/'
};
//use a template file with nodemailer
transporter.use('compile', hbs(handlebarOptions))


  var mailOptions = {
    from: emailConfig.senderEmailID,
    to: req.body.toEmail,
    subject: 'Thanks for your interest',
     template: 'email_temp', // the name of the template file i.e email.handlebars
     context:{
       username: req.body.customerName, // replace {{name}} with Adebola
       description:req.body.content
     }
    //html:'<h3>Your enquiry is submitted successfully</h3><br><p>Soon we will contact back</p>'
    
  };
 
  //Email Template completed
  
  // Save enquiry in the database
   enquiry
     .save(enquiry)
     .then(data => {
      
      res.send(data);
      
       //Triggering Email
       try{
      transporter.sendMail(mailOptions, function(error, info){
         if (error) {
           console.log(error);
         } else {
           console.log('Email sent: ' + info.response);
         }
       });
     }
     catch{
      console.log('Email unable to send: ' + info.response);
     }




     })
     .catch(err => {
       res.status(500).send({
         message:
           err.message || "Some error occurred while creating the enquiry."
       });
    });
};
// Retrieve all Tutorials from the database. 
exports.findAll = (req, res) => {
    //Enq by Specific element
    const title = req.query.customerName;
    var condition = title ? { customerName: { $regex: new RegExp(title), $options: "i" } } : {};
    console.log("Enq apge condition",condition); 
    Enquiries.find(condition)
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving enquiries."
        });
      });
};
// Find a single Tutorial with an id 
exports.findOne = (req, res) => {
    const id = req.params.id;
    Enquiries.findById(id)
      .then(data => {
        if (!data)
          res.status(404).send({ message: "Not found enquiry with id " + id });
        else res.send(data);
      })
      .catch(err => {
        res
          .status(500)
          .send({ message: "Error retrieving enquiry with id=" + id });
      });
};

 
// Update a Tutorial by the id in the request
exports.update = (req, res) => {
    if (!req.body) {
        return res.status(400).send({
          message: "Data to update can not be empty!"
        });
      }
      const id = req.params.id;
      Enquiries.findByIdAndUpdate(id, req.body, { useFindAndModify: false })
        .then(data => {
          if (!data) {
            res.status(404).send({
              message: `Cannot update Tutorial with id=${id}. Maybe Tutorial was not found!`
            });
          } else res.send({ message: "Enquiry was updated successfully." });
        })
        .catch(err => {
          res.status(500).send({
            message: "Error updating enquiry with id=" + id
          });
        });
};
// Delete a Tutorial with the specified id in the request
exports.delete = (req, res) => {
    const id = req.params.id;
    Enquiries.findByIdAndRemove(id)
      .then(data => {
        if (!data) {
          res.status(404).send({
            message: `Cannot delete enquiry with id=${id}. Maybe Tutorial was not found!`
          });
        } else {
          res.send({
            message: "Enquiry was deleted successfully!"
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Could not delete Enquiry with id=" + id
        });
      });
};
// Delete all Tutorials from the database.
exports.deleteAll = (req, res) => {
    const id = req.params.id;
    Enquiries.findByIdAndRemove(id)
      .then(data => {
        if (!data) {
          res.status(404).send({
            message: `Cannot delete Enquiry with id=${id}. Maybe Tutorial was not found!`
          });
        } else {
          res.send({
            message: "Enquiry was deleted successfully!"
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Could not delete Enquiry with id=" + id
        });
      });
};
// Find all published Tutorials
exports.findAllPublished = (req, res) => {
    Enquiries.find({ published: true })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving enquiries."
      });
    });
};