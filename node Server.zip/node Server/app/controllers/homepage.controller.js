const db = require("../models");
const HomePage = db.homepages; 
exports.findAll = (req, res) => {
  //Enq by Specific element
  const title = req.query.processName;
  var condition = title ? { processName: { $regex: new RegExp(title), $options: "i" } } : {};
  console.log("Home Page Get API"); 
  HomePage.find(condition)
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving data."
      });
    });
};


exports.findOne = (req, res) => {
    const id = req.params.id;
    console.log("Requested ID is",id);
      HomePage.findById(id)
      .then(data => {
        if (!data)
          res.status(404).send({ message: "Not found enquiry with id " + id });
        else res.send(data);
      })
      .catch(err => {
        res
          .status(500)
          .send({ message: "Error retrieving enquiry with id=" + id });
      });
};

exports.update = (req, res) => {
    if (!req.body) {
        return res.status(400).send({
          message: "Data to update can not be empty!"
        });
      }
      const id = req.params.id;
      HomePage.findByIdAndUpdate(id, req.body, { useFindAndModify: false })
        .then(data => {
          if (!data) {
            res.status(404).send({
              message: `Cannot update Tutorial with id=${id}. Maybe Tutorial was not found!`
            });
          } else res.send({ message: "Enquiry was updated successfully." });
        })
        .catch(err => {
          res.status(500).send({
            message: "Error updating enquiry with id=" + id
          });
        });
};