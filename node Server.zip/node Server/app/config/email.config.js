module.exports={
    
    senderEmailID:"email@gmail.com",
    senderEmailPassword:"smtpPassword"
 
};
