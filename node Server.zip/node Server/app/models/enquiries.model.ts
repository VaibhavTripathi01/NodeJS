// module.exports = mongoose => {
//     const enquiries = mongoose.model(
//       "enquiries",
//       mongoose.Schema(
//         {     
//             customerName:String,
//             toEmail:String,
//             subject:String,
//             body:String,
//             contactNumber:Number  
//         },
//         { timestamps: true }
       
//       )
//     );
//     return enquiries;
//   };

  module.exports = mongoose => {
    var schema = mongoose.Schema(
      {
            customerName:String,
            toEmail:String,
            subject:String,
            content:String,
            contactNumber:String  
      },
      { timestamps: true } 
    );
    schema.method("toJSON", function() {
      const { __v, _id, ...object } = this.toObject();
      object.id = _id;
      return object;
    });
    const enq = mongoose.model("enquiries", schema);
    return enq;
  };