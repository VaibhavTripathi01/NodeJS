const dbConfig = require("../config/db.config.js");
const mongoose = require("mongoose");
mongoose.Promise = global.Promise;
const db = {};
db.mongoose = mongoose;
db.url = dbConfig.url;
db.enquiries = require("./enquiries.model.ts")(mongoose);   
db.homepages = require("./homepage.model.ts")(mongoose);   
module.exports = db;

//app.use(...);