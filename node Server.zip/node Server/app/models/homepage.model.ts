module.exports = mongoose => {
    var schema = mongoose.Schema(
      {
            processName:String,
            homePageContactNumber:String,    
            homePageHeading:String,  
            homePageContent:String,
            aboutUsHeading:String,  
            aboutUs_Subheading:String,
            aboutUs_Content:String,
            services_Heading:String,  
            services_Subheading:String,
            services_Content:String,
            contactNumber:String  
      },
      { timestamps: true }
    );
    schema.method("toJSON", function() {
      const { __v, _id, ...object } = this.toObject();
      object.id = _id;
      return object;
    });  
    const home = mongoose.model("homepages", schema);
    return home;
  };