module.exports = app => {
    const homepage_info = require("../controllers/homepage.controller.js");
    var router = require("express").Router();
    router.get("/", homepage_info.findAll);
    router.get("/:id", homepage_info.findOne); 
    app.use('/api/homepages', router);    
}
   