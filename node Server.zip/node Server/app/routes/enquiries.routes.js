module.exports = app => {
    const enquiries = require("../controllers/enquiries.controller.js");
    var router = require("express").Router();
   
    // Create a new Tutorial
    router.post("/", enquiries.create);
    // Retrieve all enquiries
       router.get("/", enquiries.findAll);
    // Retrieve all published enquiries
    router.get("/published", enquiries.findAllPublished);
    // Retrieve a single Tutorial with id
    router.get("/:id", enquiries.findOne); 
    // Update a Tutorial with id
    router.put("/:id", enquiries.update);
    // Delete a Tutorial with id
    router.delete("/:id", enquiries.delete);
    // Create a new Tutorial
    router.delete("/", enquiries.deleteAll);
    
    app.use('/api/enquiries', router);  
  };